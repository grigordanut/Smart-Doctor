package com.example.danut.smartdoctor.model

class History
