package com.example.danut.smartdoctor.utils;

public class NFCReaderApp {
}
