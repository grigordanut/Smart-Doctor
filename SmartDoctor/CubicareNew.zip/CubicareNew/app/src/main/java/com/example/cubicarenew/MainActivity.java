package com.example.cubicarenew;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.shapes.RectShape;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.text.DecimalFormat;

import static java.lang.Double.doubleToLongBits;
import static java.lang.Double.parseDouble;
import static java.lang.Double.sum;
import static java.lang.Double.valueOf;

public class MainActivity extends AppCompatActivity {

    public EditText lungime, latime, grosime, pret;
    public Button buttonVolum, buttonPret, buttonClearLungime, buttonClearLatime, buttonClearGrosime, buttonClearPret;
    public Button buttonClearAll;
    public TextView textViewVolum, textViewPret;
    public Double lung_ime;
    public Double gros_ime;
    public Double lat_ime;
    public Double pr_et;
    public Double total_volum = 0.00;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        lungime = findViewById(R.id.etLungime);
        grosime = findViewById(R.id.etGrosime);
        latime = findViewById(R.id.etLatime);
        pret= findViewById(R.id.etPret);

        textViewVolum = findViewById(R.id.tvVolum);
        textViewPret = findViewById(R.id.tvPret);

        latime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                latime.setBackgroundResource(R.drawable.round_text_log);
            }
        });

        buttonVolum = findViewById(R.id.btnVolum);
        buttonVolum.setOnClickListener(new View.OnClickListener() {
            @SuppressLint({"SetTextI18n", "NewApi"})
            @Override
            public void onClick(View v) {

//                lung_ime = Double.parseDouble(lungime.getText().toString());
//                gros_ime = Double.parseDouble(grosime.getText().toString());
//                lat_ime = Double.parseDouble(latime.getText().toString());

                if (TextUtils.isEmpty(String.valueOf(lung_ime))){
//                    // Create a border programmatically
//                    ShapeDrawable shape = new ShapeDrawable(new RectShape());
//                    shape.getPaint().setColor(Color.RED);
//                    shape.getPaint().setStyle(Paint.Style.STROKE);
//                    shape.getPaint().setStrokeWidth(10);
//
//                    // Assign the created border to EditText widget
//                    latime.setBackground(shape);
                    alertDialogLungime();
                    lungime.requestFocus();
                }
                else if(TextUtils.isEmpty(String.valueOf(gros_ime))){
                    alertDialogGrosime();
                    grosime.requestFocus();
                }

                else if(TextUtils.isEmpty(String.valueOf(lat_ime))){
                    alertDialogLatime();
                    latime.requestFocus();
                }

                else {
                    lung_ime = Double.parseDouble((lungime.getText().toString()));
                    gros_ime = Double.parseDouble(grosime.getText().toString());
                    lat_ime = Double.parseDouble(latime.getText().toString());

                    total_volum = (lung_ime*gros_ime*lat_ime)/10000;

                    total_volum = roundTwoDecimalsVolum(total_volum);
                    textViewVolum.setText(total_volum+" m3");
                    buttonPret.setEnabled(true);
                }
            }
        });

        buttonPret = findViewById(R.id.btnPret);
        buttonPret.setOnClickListener(new View.OnClickListener() {
            @SuppressLint({"DefaultLocale", "SetTextI18n"})
            @Override
            public void onClick(View v) {

                pr_et = Double.parseDouble(pret.getText().toString());

                if ((TextUtils.isEmpty(String.valueOf(total_volum)) && ((TextUtils.isEmpty(String.valueOf(total_volum)))))){
                    alertDialogVolumPretLipsa();
                }

                else if (TextUtils.isEmpty(String.valueOf(total_volum))){
                    alertDialogVolumLipsa();
                }

                else if (TextUtils.isEmpty(String.valueOf(pr_et))){
                    alertDialogPretLipsa();
                    pret.requestFocus();
                }

                else {
                    //total_volumNew = Double.valueOf(totalVolum.getText().toString());
                    pr_et = Double.parseDouble(pret.getText().toString());

                    double total_pret = total_volum *pr_et;

                    //total_pret = roundTwoDecimalsPret(total_pret);
                    //textViewPret.setText(total_pret+" Lei");
                    textViewPret.setText(String.format("%,.2f", total_pret)+" Lei" );
                }
            }
        });

        buttonClearLungime = findViewById(R.id.btnClearLungime);
        buttonClearLungime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                lungime.setText("");
                textViewVolum.setText("");
                textViewPret.setText("");
                lungime.requestFocus();
            }
        });

        buttonClearGrosime = findViewById(R.id.btnClearGrosime);
        buttonClearGrosime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                grosime.setText("");
                textViewVolum.setText("");
                textViewPret.setText("");
                grosime.requestFocus();
            }
        });

        buttonClearLatime = findViewById(R.id.btnClearLatime);
        buttonClearLatime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                latime.setText("");
                textViewVolum.setText("");
                textViewPret.setText("");
                latime.requestFocus();
            }
        });

        buttonClearPret = findViewById(R.id.btnClearPret);
        buttonClearPret.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pret.setText("");
                textViewPret.setText("");
                pret.requestFocus();
            }
        });

        buttonClearAll = findViewById(R.id.btnClearAll);
        buttonClearAll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                lungime.setText("");
                grosime.setText("");
                latime.setText("");
                textViewVolum.setText("");
                pret.setText("");
                textViewPret.setText("");
                lungime.requestFocus();
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public double roundTwoDecimalsVolum(double total_volum){
        DecimalFormat twoDFormV = new DecimalFormat("#.##");
        return  valueOf(twoDFormV.format(total_volum));
    }

    public double roundTwoDecimalsPret(double total_pret){
        DecimalFormat twoDFormV = new DecimalFormat("#.##");
        return  valueOf(twoDFormV.format(total_pret));
    }

    public void alertDialogLungime(){
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
        alertDialogBuilder.setMessage("Adaugă valoare Lungime");
        alertDialogBuilder.setPositiveButton("OK",
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface arg0, int arg1) {
                    }
                });

        AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.show();
    }

    public void alertDialogLatime(){
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
        alertDialogBuilder.setMessage("Adaugă valoare Lăţime");
        alertDialogBuilder.setPositiveButton("OK",
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface arg0, int arg1) {
                    }
                });

        AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.show();
    }

    public void alertDialogGrosime(){
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
        alertDialogBuilder.setMessage("Adaugă valoare Grosime");
        alertDialogBuilder.setPositiveButton("OK",
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface arg0, int arg1) {
                    }
                });

        AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.show();
    }

    public void alertDialogVolumPretLipsa(){
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
        alertDialogBuilder.setMessage("Calculaţi Volumul şi Introduceţi Preţul");
        alertDialogBuilder.setPositiveButton("OK",
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface arg0, int arg1) {
                    }
                });

        AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.show();
    }

    public void alertDialogVolumLipsa(){
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
        alertDialogBuilder.setMessage("Calculaţi Volumul");
        alertDialogBuilder.setPositiveButton("OK",
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface arg0, int arg1) {
                    }
                });

        AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.show();
    }

    public void alertDialogPretLipsa(){
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
        alertDialogBuilder.setMessage("Introduceţi Preţul");
        alertDialogBuilder.setPositiveButton("OK",
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface arg0, int arg1) {
                    }
                });

        AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.show();
    }
}
